function doublecheck(){

   
    var yes = confirm('你確定嗎？');

if (yes) {
    alert('已送出訂單');
} else {
    alert('已取消訂單');
}
}