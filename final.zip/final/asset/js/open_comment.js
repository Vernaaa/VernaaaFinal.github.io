function openwin() {

    window.open("comment.html", "newwindow",
      "height=600, width=700, toolbar=no, menubar=no, scrollbars=no, resizable=no, location=no, status=no")

}